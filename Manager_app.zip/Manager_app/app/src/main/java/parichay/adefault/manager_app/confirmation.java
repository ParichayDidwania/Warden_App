package parichay.adefault.manager_app;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.service.autofill.Dataset;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import org.w3c.dom.Text;

import java.util.ArrayList;

public class confirmation extends AppCompatActivity {

    String uid;
    String random;
    String service_next;
    TextView name;
    TextView service;
    TextView flat;
    TextView location;
    TextView landmark;
    ArrayList<String> address;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_confirmation);
        setTitle("Confirmation");
        uid = getIntent().getStringExtra("uid");
        random = getIntent().getStringExtra("random");
        name = (TextView)findViewById(R.id.textView4);
        service = (TextView)findViewById(R.id.textView8);
        flat = (TextView)findViewById(R.id.textView10);
        location = (TextView)findViewById(R.id.textView11);
        landmark = (TextView)findViewById(R.id.textView12);
        address = new ArrayList<>();


        FirebaseDatabase.getInstance().getReference().child("Users").child(uid).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot dataSnapshot) {
                name.setText("Name : "+dataSnapshot.child("Name").getValue().toString());
                service.setText("Service : "+dataSnapshot.child("Orders").child(random).child("service").getValue().toString());
                for(DataSnapshot snapshot : dataSnapshot.child("Address").getChildren())
                {
                    address.add(snapshot.getValue().toString());
                }
                flat.setText("FlatNo : "+address.get(0));
                landmark.setText("Landmark : "+address.get(1));
                location.setText("Location : "+address.get(2));

                service_next = dataSnapshot.child("Orders").child(random).child("service").getValue().toString();
            }

            @Override
            public void onCancelled(@NonNull DatabaseError databaseError) {

            }
        });


    }

    public void assign(View view)
    {
        Intent i = new Intent(this,Emplist.class);
        i.putExtra("service",service_next);
        i.putExtra("random",random);
        startActivity(i);
    }
}
